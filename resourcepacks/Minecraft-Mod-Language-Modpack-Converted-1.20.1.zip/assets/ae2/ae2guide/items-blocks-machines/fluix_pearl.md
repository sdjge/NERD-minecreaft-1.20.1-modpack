---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福鲁伊克斯珍珠
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# 福鲁伊克斯珍珠

<ItemImage id="fluix_pearl" scale="4" />

覆有一层<ItemLink id="fluix_crystal" />的末影珍珠，用于制造若干种AE2组件。

## 配方

<RecipeFor id="fluix_pearl" />
