---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福鲁伊克斯块
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# 福鲁伊克斯块

<BlockImage id="fluix_block" scale="8" />

<ItemLink id="fluix_crystal" />的存储方块。也用在部分机器的配方中。

## 配方

<RecipeFor id="fluix_block" />
